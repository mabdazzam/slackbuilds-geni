/* Kludgy formatting routine for undeltk
   (just because this was easier than figuring out how to do it in tcl)

   Takes 3 parameters:
	- filename string
	- date string
	- total length of the entry

   Left justifies the filename, right justifies the date, then places
   dots "." between them.
*/

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "safedelete.h"

int main(argc, argv)
  int argc;
  char **argv;
{
int i, str1l, str2l, totlenth;

char WorkBuf[WORK_BUF_LEN];

  if(argc != 4)
  {
    printf("Usage: udtkfmt filename date length\n");
    return 1;
  }

  for(i=0; i<WORK_BUF_LEN; i+=2)
  {
    WorkBuf[i]='.';
    WorkBuf[i+1]=' ';
  }

  str1l=strlen(argv[1]);
  str2l=strlen(argv[2]);
  totlenth=atoi(argv[3]); 

/* Copy filename to work buffer and make sure it ends with a space */

  strcpy(WorkBuf, argv[1]);  
  WorkBuf[str1l]=' ';

  if((str1l+str2l) < totlenth-3)
  {
    i=totlenth-str2l;
    strcpy(WorkBuf+i, argv[2]);
  }
  else
    sprintf(WorkBuf+(str1l), " . %s", argv[2]);

  printf("%s", WorkBuf);
  return 0;
}
