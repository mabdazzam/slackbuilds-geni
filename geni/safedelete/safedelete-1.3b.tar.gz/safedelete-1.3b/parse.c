/* ParseFileName
   Parses passed file name into directory and file name portions.

   passsed: pointer to null-delimited fully qualified file name.

   returns: offset of '/' delimiting the directory and file name

   Example:  passed:  "/etc/profile"
                 returns: 4
                 passed: "/usr/local/src/safedelete-1.0/safedelete.c
                 returns: 29
*/

int  ParseFileName(FileName)
  char *FileName;
{
char *wrkptr;

  for(wrkptr=FileName+strlen(FileName); *wrkptr != '/'; wrkptr--);
  return (int)(wrkptr-FileName);
}
