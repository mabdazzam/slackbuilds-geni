#include <string.h>

/* RecLen
   Find end of current record indicated by a newline character.
 
Passed: pointer to record from .safedelete.log
  
Returns: length of record
*/

int RecLen(Rec)
  char *Rec;
{
char *wrkptr;

  for(wrkptr=Rec; *wrkptr != '\n'; wrkptr++);

  return (int)(wrkptr-Rec)+1;
}
